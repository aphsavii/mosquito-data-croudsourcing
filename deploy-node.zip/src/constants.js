const DEFAULT_AVATAR = "https://res.cloudinary.com/dejbo7uw5/image/upload/v1710239207/avatar/a8bqciw2nf5debbtnfft.jpg";



export {
DEFAULT_AVATAR

}